from . import crm_lead
from . import crm_lead_line
from . import crm_lead_segment
from . import crm_lead_type
from . import crm_lead_subsegment
from . import sales_target
from . import sale_order
from . import crm_lost_reason
from . import product_category


